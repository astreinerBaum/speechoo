#pragma once

#include "resource.h"

void DebugOut(HWND hWnd, wchar_t *str);
