These are tools for building recognition grammar for Julian.
Julian uses original grammar format.

  mkdfa (mkdfa.pl)  grammar compiler
  dfa_minimize	    minimize DFA grammar
  generate	    randam sentence generation tool
  accept_check	    tool to check acception/rejection of input sentence
  nextword	    display next predicted words of given partial sentence
  gram2sapixml	    perl script to convert Julian grammar to SAPI XML format
  dfa_determinize   DFA determinizer

Please see online manual or "00readme.txt" file under each directory.
Other document in Juliusbook or on the Web site will also helps you.

   http://julius.sourceforge.jp/en/

